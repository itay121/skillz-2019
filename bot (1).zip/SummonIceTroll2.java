package bots.mission;

import bots.*;
import bots.wrapper.*;

import java.util.*;


public class SummonIceTroll2 implements Mission<MyPortal> {
    
    @Override
    public State act(MyPortal p) {
        if (p.summonIceTroll()) {
            return State.CONTINUE;
        }
        return State.PASS;
    }
    
}